# SleepMute — prototype

Coupe automatiquement la musique quand tu t'endors, grâce à ta Xiaomi Watch 2 (Wear OS).

## Architecture
- **wear/** : app montre — détecte le sommeil via Health Services (API officielle Wear OS)
  et envoie un message au téléphone.
- **mobile/** : app téléphone — reçoit le message et envoie une commande PAUSE
  qui fonctionne avec YouTube, Spotify, Netflix, lecteurs locaux, etc.

## Installation (première fois)

1. Installe **Android Studio** (version récente) : https://developer.android.com/studio
2. Ouvre ce dossier `SleepMute` dans Android Studio et laisse-le synchroniser
   (il va télécharger Gradle et créer les fichiers nécessaires).
3. Installe l'app **mobile** sur ton téléphone :
   - branche le téléphone en USB, autorise le débogage USB
   - dans Android Studio, sélectionne la configuration `mobile` et clique ▶
4. Installe l'app **wear** sur la montre :
   - sur la montre : Paramètres → Système → À propos → appuie 7 fois sur "Numéro de build"
     pour activer les options développeur
   - active "Débogage ADB" et "Débogage via Wi-Fi"
   - la montre affiche une IP. Sur le PC (avec le téléphone branché en USB qui sert de relais) :
     ```
     adb forward tcp:4444 localabstract:/adb-hub
     adb connect 192.168.x.x:4444
     ```
   - dans Android Studio, sélectionne la configuration `wear` et clique ▶

## Utilisation
1. Sur la montre : ouvre SleepMute → "Activer" → autorise les capteurs.
2. Sur le téléphone : lance ta musique (YouTube, Spotify, etc.).
3. Dors. La musique se met en pause toute seule quand tu t'endors. 😴

## Dépannage
- Les deux apps doivent être installées avec le même nom de paquet (déjà fait : com.sleepmute.app).
- Si rien ne se passe : vérifie que la montre et le téléphone sont appairés
  avec le même compte Google, et désactive l'optimisation batterie pour SleepMute.
- Version des librairies : si la compilation échoue sur une dépendance,
  remplace-la par la version la plus récente affichée sur
  https://maven.google.com (rechercher "health-services-client", "play-services-wearable").

---

## 🔥 Méthode SANS ordinateur (compilation dans le cloud)

Pas de PC ? GitHub compile les APK à ta place, gratuitement.

### Étape 1 — Compiler dans le cloud (~10 minutes, une seule fois)
1. Crée un compte gratuit sur https://github.com
2. Clique sur **"New repository"**, nomme-le `SleepMute`, laisse-le public, crée-le
3. Sur la page du nouveau dépôt : **"uploading an existing file"** →
   glisse-dépose **tout le contenu du dossier SleepMute** (y compris le dossier caché `.github`)
4. Va dans l'onglet **Actions** → clique **"Run workflow"** à droite → **"Run workflow"**
5. Attends 5-10 minutes (cercle vert ✅) → clique sur la tâche → tout en bas,
   section **Artifacts** → télécharge `sleepmute-apks`
6. Décompresse le fichier : tu obtiens deux APK

### Étape 2 — Installer sur le téléphone
1. Transfère `mobile-debug.apk` sur ton téléphone (téléchargement direct ou Google Drive)
2. Ouvre-le → autorise l'installation depuis cette source si demandé → installe

### Étape 3 — Installer sur la montre (sans PC)
1. Sur la montre : Paramètres → Système → À propos → tape 7 fois sur **"Numéro de build"**
2. Retour : Paramètres → Options pour les développeurs → active
   **"Débogage ADB"** et **"Débogage sans fil"** → note le code de jumelage et l'IP affichés
3. Sur le téléphone : installe **Wear Installer 2** (Play Store, gratuit, par dalít)
4. Ouvre-le → jumelle-le avec la montre (même Wi-Fi, code affiché sur la montre)
5. Sélectionne `wear-debug.apk` dans tes fichiers → envoie vers la montre → installe

### Étape 4 — Utiliser
1. Montre : ouvre SleepMute → "Activer" → autorise les capteurs
2. Téléphone : lance ta musique
3. Dors. 😴

## ⚠️ Si tu modifies le code plus tard
Chaque fois que tu enverras une nouvelle version sur GitHub, la compilation
repart automatiquement et tu pourras retélécharger les APK à jour.
